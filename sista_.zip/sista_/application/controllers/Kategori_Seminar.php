<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori_Seminar extends CI_Controller
{

    public function index()
    {
        $data['judul'] = 'SISTA : Kategori Seminar';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('KategoriS_model');
        $data['dosen'] = $this->KategoriS_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kategori_seminar/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_k()
    {
        $data['judul'] = 'Tambah Kategori';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('KategoriS_model');
        // $this->session->set_flashdata('flash', 'Added');
        $data['kategori_seminar'] = $this->KategoriS_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kategori_seminar/tambah_k', $data);
        $this->load->view('templates/footer');
    }

    public function save()
    {
        $this->load->model('KategoriS_model', 'kategori_seminar');
        $_nama = $this->input->post('nama_seminar');
        $_idedit = $this->input->post('idedit');

        $data_ks['nama_seminar'] = $_nama;

        if (!empty($_idedit)) {
            $data_ks['id'] = $_idedit;
            $this->kategori_seminar->update($data_ks);
        } else {
            $this->kategori_seminar->simpan($data_ks);
        }
        redirect('kategori_seminar');
    }

    public function edit($id)
    {
        $data['judul'] = 'Edit Kategori';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('KategoriS_model', 'kategori_seminar');
        $obj_ks = $this->kategori_seminar->findById($id);
        $data['obj_ks'] = $obj_ks;

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('kategori_seminar/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->load->model('KategoriS_model', 'kategori_seminar');
        $data_ks['id'] = $id;
        $this->kategori_seminar->delete($data_ks);
        //$this->session->set_flashdata('flash', 'Deleted');
        redirect('kategori_seminar');
    }
}
