<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{


    public function index()
    {
        $data['judul'] = 'SISTA : Seminar TA';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Seminar_model');
        $data['seminar_ta'] = $this->Seminar_model->getAll();
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();
        $data['dosen'] = $this->db->get('dosen')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');

        //$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New seminar data added!</div>');
        //redirect('admin');
    }

    public function tambah_sem()
    {
        $data['judul'] = 'Tambah Data Seminar';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Seminar_model');
        // $this->session->set_flashdata('flash', 'Added');
        $data['seminar_ta'] = $this->Seminar_model->getAll();
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();
        $data['dosen'] = $this->db->get('dosen')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/tambah_sem', $data);
        $this->load->view('templates/footer');
    }

    public function save()
    {
        $this->load->model('Seminar_model', 'seminar_ta');
        $_smt = $this->input->post('semester');
        $_tgl = $this->input->post('tanggal');
        $_jam = $this->input->post('jam');
        $_ksi = $this->input->post('kategori_seminar_id');
        $_nim = $this->input->post('nim');
        $_namamhs = $this->input->post('nama_mahasiswa');
        $_jdl = $this->input->post('judul');
        $_pembimbing = $this->input->post('pembimbing_id');
        $_penguji1 = $this->input->post('penguji1_id');
        $_penguji2 = $this->input->post('penguji2_id');
        $_np = $this->input->post('nilai_pembimbing');
        $_np1 = $this->input->post('nilai_penguji1');
        $_np2 = $this->input->post('nilai_penguji2');
        $_lokasi = $this->input->post('lokasi');
        $_na = $this->input->post('nilai_akhir');
        $_idedit = $this->input->post('idedit');

        $data_sem['semester'] = $_smt;
        $data_sem['tanggal'] = $_tgl;
        $data_sem['jam'] = $_jam;
        $data_sem['kategori_seminar_id'] = $_ksi;
        $data_sem['nim'] = $_nim;
        $data_sem['nama_mahasiswa'] = $_namamhs;
        $data_sem['judul'] = $_jdl;
        $data_sem['pembimbing_id'] = $_pembimbing;
        $data_sem['penguji1_id'] = $_penguji1;
        $data_sem['penguji2_id'] = $_penguji2;
        $data_sem['nilai_pembimbing'] = $_np;
        $data_sem['nilai_penguji1'] = $_np1;
        $data_sem['nilai penguji2'] = $_np2;
        $data_sem['lokasi'] = $_lokasi;
        $data_sem['nilai_akhir'] = $_na;

        if (!empty($_idedit)) {
            $data_sem['id'] = $_idedit;
            $this->seminar_ta->update($data_sem);
        } else {
            $this->seminar_ta->simpan($data_sem);
        }
        redirect('admin');
    }

    public function edit($id)
    {
        $data['judul'] = 'Edit Data Seminar';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Seminar_model', 'seminar_ta');
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();
        $data['dosen'] = $this->db->get('dosen')->result_array();
        $obj_sem = $this->seminar_ta->findById($id);
        $data['obj_sem'] = $obj_sem;

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->load->model('Seminar_model', 'seminar_ta');
        $data_sem['id'] = $id;
        $this->seminar_ta->delete($data_sem);
        //$this->session->set_flashdata('flash', 'Deleted');
        redirect('admin');
    }
}
