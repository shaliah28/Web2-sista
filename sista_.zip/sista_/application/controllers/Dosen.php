<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dosen extends CI_Controller
{

    public function index()
    {
        $data['judul'] = 'SISTA : Dosen';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Dosen_model');
        $data['dosen'] = $this->Dosen_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('dosen/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_d()
    {
        $data['judul'] = 'Tambah Data Dosen';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Dosen_model');
        // $this->session->set_flashdata('flash', 'Added');
        $data['dosen'] = $this->Dosen_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('dosen/tambah_d', $data);
        $this->load->view('templates/footer');
    }

    public function save()
    {
        $this->load->model('Dosen_model', 'dosen');
        $_nidn = $this->input->post('nidn');
        $_nama = $this->input->post('nama');
        $_idedit = $this->input->post('idedit');

        $data_dosen['nidn'] = $_nidn;
        $data_dosen['nama'] = $_nama;

        if (!empty($_idedit)) {
            $data_dosen['id'] = $_idedit;
            $this->dosen->update($data_dosen);
        } else {
            $this->dosen->simpan($data_dosen);
        }
        redirect('dosen');
    }

    public function edit($id)
    {
        $data['judul'] = 'Edit Data Dosen';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Dosen_model', 'dosen');
        $obj_dosen = $this->dosen->findById($id);
        $data['obj_dosen'] = $obj_dosen;

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('dosen/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->load->model('Dosen_model', 'dosen');
        $data_dosen['id'] = $id;
        $this->dosen->delete($data_dosen);
        //$this->session->set_flashdata('flash', 'Deleted');
        redirect('dosen');
    }
}
