<?php

class Jadwal extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Jadwal_model');
	}

	public function index()
	{
		$data['judul'] = 'SISTA : Jadwal';
		$data['jadwal'] = $this->Jadwal_model->getJadwal();

		$this->load->view('jadwal/index', $data);
	}

	public function login()
	{
		$data['judul'] = 'SISTA : Login';

		$this->load->view('auth/login', $data);
	}
}
