<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Peserta extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Peserta_model');
    }

    public function index()
    {
        $data['judul'] = 'SISTA : Peserta Seminar';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['peserta_seminar'] = $this->Peserta_model->getAll();
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('peserta/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul'] = 'Tambah Data Peserta';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Peserta_model');
        // $this->session->set_flashdata('flash', 'Added');
        $data['peserta_seminar'] = $this->Peserta_model->getAll();
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('peserta/tambah', $data);
        $this->load->view('templates/footer');
    }

    public function save()
    {
        $this->load->model('Peserta_model', 'peserta_seminar');
        $_nim = $this->input->post('nim');
        $_namamhs = $this->input->post('nama_mahasiswa');
        $_seminar = $this->input->post('seminar_id');
        $_kehadiran = $this->input->post('kehadiran');
        $_idedit = $this->input->post('idedit');

        $data_ps['nim'] = $_nim;
        $data_ps['nama_mahasiswa'] = $_namamhs;
        $data_ps['seminar_id'] = $_seminar;
        $data_ps['kehadiran'] = $_kehadiran;

        if (!empty($_idedit)) {
            $data_ps['id'] = $_idedit;
            $this->peserta_seminar->update($data_ps);
        } else {
            $this->peserta_seminar->simpan($data_ps);
        }
        redirect('peserta');
    }

    public function edit($id)
    {
        $data['judul'] = 'Edit Data Peserta';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Peserta_model', 'peserta_seminar');
        $data['kategori_seminar'] = $this->db->get('kategori_seminar')->result_array();
        $obj_ps = $this->peserta_seminar->findById($id);
        $data['obj_ps'] = $obj_ps;

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('peserta/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->load->model('Peserta_model', 'peserta_seminar');
        $data_ps['id'] = $id;
        $this->peserta_seminar->delete($data_ps);
        //$this->session->set_flashdata('flash', 'Deleted');
        redirect('peserta');
    }
}
