<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penilaian extends CI_Controller
{

    public function index()
    {
        $data['judul'] = 'SISTA : Penilaian';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Penilaian_model');
        $data['penilaian'] = $this->Penilaian_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('penilaian/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah_p()
    {
        $data['judul'] = 'Tambah Data Penilaian';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Penilaian_model');
        // $this->session->set_flashdata('flash', 'Added');
        $data['dosen'] = $this->Penilaian_model->getAll();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('penilaian/tambah_p', $data);
        $this->load->view('templates/footer');
    }

    public function save()
    {
        $this->load->model('Penilaian_model', 'penilaian');
        $_nama = $this->input->post('nama');
        $_ket = $this->input->post('keterangan');
        $_idedit = $this->input->post('idedit');

        $data_p['nama'] = $_nama;
        $data_p['keterangan'] = $_ket;

        if (!empty($_idedit)) {
            $data_p['id'] = $_idedit;
            $this->penilaian->update($data_p);
        } else {
            $this->penilaian->simpan($data_p);
        }
        redirect('penilaian');
    }

    public function edit($id)
    {
        $data['judul'] = 'Edit Data Penilaian';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->model('Penilaian_model', 'penilaian');
        $obj_p = $this->penilaian->findById($id);
        $data['obj_p'] = $obj_p;

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('penilaian/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->load->model('Penilaian_model', 'penilaian');
        $data_p['id'] = $id;
        $this->penilaian->delete($data_p);
        //$this->session->set_flashdata('flash', 'Deleted');
        redirect('penilaian');
    }
}
