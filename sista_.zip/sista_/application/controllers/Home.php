<?php

class Home extends CI_Controller
{

	public function index()
	{
		$data['judul'] = 'SISTA : Home';

		$this->load->view('home/index', $data);
	}

	public function login()
	{
		$data['judul'] = 'SISTA : Login';

		$this->load->view('auth/login', $data);
	}
}
