<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul ?></h1>

    <div class="row mt-3">
        <div class="col-md-8">
            <?= form_open('peserta/save'); ?>
            <div class="card">
                <div class="card-header">
                    Form Edit Data Peserta
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="nim">NIM</label>
                        <input type="text" class="form-control" id="nim" name="nim" value="<?= $obj_ps['nim']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?= $obj_ps['nama_mahasiswa']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="kehadiran">Seminar</label>
                        <select class="form-control" id="seminar_id" name="seminar_id" value="<?= $obj_ps['seminar_id']; ?>">
                            <option value="">Pilih Kategori</option>
                            <?php foreach ($kategori_seminar as $ks) : ?>
                                <option value="<?= $ks['id']; ?>"><?= $ks['nama_seminar']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="kehadiran">Kehadiran</label>
                        <input type="text" class="form-control" id="kehadiran" name="kehadiran" value="<?= $obj_ps['kehadiran']; ?>">
                    </div>
                    <div class=" form-group row">
                        <div class="col-8">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" name="idedit" value="<?= $obj_ps['id']; ?>">
            <?= form_close() ?>
        </div>
    </div>

</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->



</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>



<!-- Script -->
<?php $this->load->view('templates/script'); ?>