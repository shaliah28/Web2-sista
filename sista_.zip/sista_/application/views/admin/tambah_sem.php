<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul ?></h1>

    <div class="row mt-3">
        <div class="col-md-8">
            <?= form_open('admin/save'); ?>
            <div class="card">
                <div class="card-header">
                    Form Tambah Data Seminar
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="semester">Semester</label>
                        <input type="text" class="form-control" id="semester" name="semester">
                    </div>
                    <div class="form-group">
                        <label for="tanggal">Tanggal</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal">
                    </div>
                    <div class="form-group">
                        <label for="jam">Waktu</label>
                        <input type="time" class="form-control" id="jam" name="jam">
                    </div>
                    <div class="form-group">
                        <label for="kategori">Kategori Seminar</label>
                        <select class="form-control" id="kategori_seminar_id" name="kategori_seminar_id">
                            <option value="">Pilih Kategori</option>
                            <?php foreach ($kategori_seminar as $ks) : ?>
                                <option value="<?= $ks['id']; ?>"><?= $ks['nama_seminar']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="nim">NIM</label>
                        <input type="text" class="form-control" id="nim" name="nim">
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama">
                    </div>
                    <div class="form-group">
                        <label for="judul">Judul</label>
                        <input type="text" class="form-control" id="judul" name="judul">
                    </div>
                    <div class="form-group">
                        <label for="pembimbing">Pembimbing</label>
                        <select class="form-control" id="pembimbing_id" name="pembimbing_id">
                            <option value="">Pilih Pembimbing</option>
                            <?php foreach ($dosen as $d) : ?>
                                <option value="<?= $d['id']; ?>"><?= $d['nama']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="penguji1">Penguji1</label>
                        <select class="form-control" id="penguji1_id" name="penguji1_id">
                            <option value="">Pilih Penguji1</option>
                            <?php foreach ($dosen as $d) : ?>
                                <option value="<?= $d['id']; ?>"><?= $d['nama']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="penguji2">Penguji2</label>
                        <select class="form-control" id="penguji2_id" name="penguji2_id">
                            <option value="">Pilih Penguji2</option>
                            <?php foreach ($dosen as $d) : ?>
                                <option value="<?= $d['id']; ?>"><?= $d['nama']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="nilai_pembimbing">Nilai Pembimbing</label>
                        <input type="text" class="form-control" id="nilai_pembimbing" name="nilai_pembimbing">
                    </div>
                    <div class="form-group">
                        <label for="nilai_penguji1">Nilai Penguji1</label>
                        <input type="text" class="form-control" id="nilai_penguji1" name="nilai_penguji1">
                    </div>
                    <div class="form-group">
                        <label for="nilai_penguji2">Nilai Penguji2</label>
                        <input type="text" class="form-control" id="nilai_penguji2" name="nilai_penguji2">
                    </div>
                    <div class="form-group">
                        <label for="lokasi">Lokasi</label>
                        <input type="text" class="form-control" id="lokasi" name="lokasi">
                    </div>
                    <div class="form-group">
                        <label for="nilai_akhir">Nilai Akhir</label>
                        <input type="text" class="form-control" id="nilai_akhir" name="nilai_akhir">
                    </div>
                    <div class="form-group row">
                        <div class="col">
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?= form_close() ?>
    </div>
</div>

</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->



</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>



<!-- Script -->
<?php $this->load->view('templates/script'); ?>