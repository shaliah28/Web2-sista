<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul ?></h1>

    <div class="row">
        <div class="col-lg-6">
            <?= form_error('semester', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
            <?= $this->session->set_flashdata('message'); ?>

            <a href="<?= base_url('admin/tambah_sem') ?>" class="btn btn-primary mb-3">Tambah</a>
        </div>
    </div>
    <!-- a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSeminarModal">Tambah</-a -->


    <!-- Tabel Peserta -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tabel Seminar TA</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Semester</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Waktu</th>
                            <th scope="col">Kategori Seminar</th>
                            <th scope="col">NIM</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Pembimbing</th>
                            <th scope="col">Penguji1</th>
                            <th scope="col">Penguji2</th>
                            <th scope="col">Nilai Pembimbing</th>
                            <th scope="col">Nilai Penguji1</th>
                            <th scope="col">Nilai Penguji2</th>
                            <th scope="col">Lokasi</th>
                            <th scope="col">Nilai Akhir</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($seminar_ta as $sta) : ?>
                            <tr>
                                <td scope="row"><?= $i; ?></td>
                                <td><?= $sta['semester'] ?></td>
                                <td><?= $sta['tanggal'] ?></td>
                                <td><?= $sta['jam'] ?></td>
                                <td><?= $sta['kategori_seminar_id'] ?></td>
                                <td><?= $sta['nim'] ?></td>
                                <td><?= $sta['nama_mahasiswa'] ?></td>
                                <td><?= $sta['judul'] ?></td>
                                <td><?= $sta['pembimbing_id'] ?></td>
                                <td><?= $sta['penguji1_id'] ?></td>
                                <td><?= $sta['penguji2_id'] ?></td>
                                <td><?= $sta['nilai_pembimbing'] ?></td>
                                <td><?= $sta['nilai_penguji1'] ?></td>
                                <td><?= $sta['nilai_penguji2'] ?></td>
                                <td><?= $sta['lokasi'] ?></td>
                                <td><?= $sta['nilai_akhir'] ?></td>
                                <td>
                                    <a href="<?= base_url('admin/edit/') . $sta['id'] ?>" class="badge badge-success">edit</a>
                                    <a href="<?= base_url('admin/delete/') . $sta['id'] ?>" class="badge badge-danger">delete</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->



</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>





<!-- Script -->
<?php $this->load->view('templates/script'); ?>