<!-- jQuery first, then Popper.js, then Bootstrap JS -->

        <script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/popper.min.js"></script>
    	<script src="js/scripts.js"></script>
  	</body>
</html>