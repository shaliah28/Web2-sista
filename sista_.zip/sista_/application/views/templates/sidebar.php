<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">WEBSITE SISTA</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider">


    <!-- Nav Item - Home -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('user/') ?>">
            <i class="fas fa-home"></i>
            <span>Home</span></a>
    </li>



    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Admin
    </div>

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('admin') ?>">
            <i class="fas fa-chalkboard"></i>
            <span>Seminar</span></a>
    </li>
    <!-- Nav Item - Kategori Seminar -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('kategori_seminar') ?>">
            <i class="fas fa-th-list"></i>
            <span>Kategori Seminar</span></a>
    </li>
    <!-- Nav Item - Peserta -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('peserta') ?>">
            <i class="fas fa-users"></i>
            <span>Peserta</span></a>
        <!-- Nav Item - Dosen -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('dosen') ?>">
            <i class="fas fa-chalkboard-teacher"></i>
            <span>Dosen</span></a>
    </li>
    <!-- Nav Item - Detail Penilaian -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('d_penilaian') ?>">
            <i class="fas fa-award"></i>
            <span>Detail penilaian</span></a>
    </li>
    <!-- Nav Item - Detail Penilaian -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('penilaian') ?>">
            <i class="fas fa-star-half-alt"></i>
            <span>Penilaian</span></a>
    </li>





    <!-- Divider -->
    <hr class="sidebar-divider">


    <!-- Nav Item - Logout -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('auth/logout'); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span></a>
    </li>


    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->