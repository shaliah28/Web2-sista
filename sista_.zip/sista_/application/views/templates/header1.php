<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $judul; ?></title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">

</head>

<body>

    <!-- header & navbar-->
    <div class="container.fluid">
        <div class="row-12">
            <div class="col-md" style="background-color: rgba(7, 149, 231, 0.767);">
                <div class="page-header" style="padding: 1pc;">
                    <h2 style="text-align: center; color: black;">
                        Sistem Informasi Seminar Tugas Akhir - SISTA
                    </h2>
                </div>
            </div>

            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item ">
                            <a class="nav-link text-primary active" href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> Jadwal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="#"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Daftar Seminar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="#"><i class="fa fa-newspaper-o" aria-hidden="true"></i> Berita</a>
                        </li>
                    </ul>
                    <!-- Topbar Search -->
                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="topbar-divider d-none d-sm-block"></div>

                <button class="btn btn-primary" type="button" href="#">Login</button>
            </nav>

        </div>
    </div>
    </div>
    <!-- end header & navbar-->