<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jadwal_model extends CI_Model
{
    public function getJadwal()
    {

        $this->db->select('seminar_ta.tanggal, seminar_ta.jam, kategori_seminar.nama_seminar AS nama_kategori, peserta_seminar.nama_mahasiswa AS nama_peserta,  dosen.nama AS nama_penguji1, seminar_ta.lokasi');
        $this->db->from('seminar_ta');
        $this->db->join('kategori_seminar', 'kategori_seminar.id=seminar_ta.kategori_seminar_id');
        $this->db->join('dosen', 'dosen.id=seminar_ta.penguji1_id');
        $this->db->join('peserta_seminar', 'peserta_seminar.seminar_id=seminar_ta.kategori_seminar_id');
        //$this->db->join('detail_penilaian', 'detail_penilaian.seminar_ta_id=seminar_ta.id');

        $query = $this->db->get();
        return $query->result();
    }
}
