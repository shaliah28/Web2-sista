<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KategoriS_model extends CI_Model
{
    public function getAll()
    {
        $query = $this->db->get('kategori_seminar');
        return $query->result_array();
    }

    public function findById($id)
    {
        $query = $this->db->get_where('kategori_seminar', array('id' => $id));
        return $query->row_array();
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO kategori_seminar (nama_seminar) VALUES (?)";
        $this->db->query($sql, $data);
    }

    public function update($data)
    {
        $sql = "UPDATE kategori_seminar SET nama_seminar=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data)
    {
        $sql = "DELETE FROM kategori_seminar WHERE id=?";
        $this->db->query($sql, $data);
    }
}
