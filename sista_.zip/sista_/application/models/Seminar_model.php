<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Seminar_model extends CI_Model
{
    public function getAll()
    {
        $query = $this->db->get('seminar_ta');
        return $query->result_array();
    }

    public function findById($id)
    {
        $query = $this->db->get_where('seminar_ta', array('id' => $id));
        return $query->row_array();
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO seminar_ta (semester, tanggal, jam, kategori_seminar_id, nim, nama_mahasiswa, judul, pembimbing_id, penguji1_id, penguji2_id, nilai_pembimbing, nilai_penguji1, nilai_penguji2, lokasi, nilai_akhir) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $this->db->query($sql, $data);
    }

    public function update($data)
    {
        $sql = "UPDATE seminar_ta SET semester=?, tanggal=?, jam=?, kategori_seminar_id=?, nim=?, nama_mahasiswa=?, judul=?, pembimbing_id=?, penguji1_id=?, penguji2_id=?, nilai_pembimbing=?, nilai_penguji1=?, nilai_penguji2=?, lokasi=?, nilai_akhir=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data)
    {
        $sql = "DELETE FROM seminar_ta WHERE id=?";
        $this->db->query($sql, $data);
    }
}
