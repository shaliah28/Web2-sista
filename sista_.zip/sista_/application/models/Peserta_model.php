<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Peserta_model extends CI_Model
{
    public function getAll()
    {
        //$query = $this->db->get('peserta_seminar');
        //return $query->result_array();
        $query = "SELECT `peserta_seminar`.*, `kategori_seminar`.`id`, `kategori_seminar`.`nama_seminar`
                FROM `peserta_seminar` JOIN `kategori_seminar`
                ON `peserta_seminar`.`seminar_id` = `kategori_seminar`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function findById($id)
    {
        $query = $this->db->get_where('peserta_seminar', array('id' => $id));
        return $query->row_array();
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO peserta_seminar (nim, nama_mahasiswa, seminar_id, kehadiran) VALUES (?, ?, ?, ?)";
        $this->db->query($sql, $data);
    }

    public function update($data)
    {
        $sql = "UPDATE peserta_seminar SET nim=?, nama_mahasiswa=?, seminar_id=?, kehadiran=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data)
    {
        $sql = "DELETE FROM peserta_seminar WHERE id=?";
        $this->db->query($sql, $data);
    }
}
