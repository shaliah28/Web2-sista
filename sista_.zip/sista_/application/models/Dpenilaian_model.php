<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dpenilaian_model extends CI_Model
{
}
