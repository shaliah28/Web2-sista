<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penilaian_model extends CI_Model
{
    public function getAll()
    {
        $query = $this->db->get('penilaian');
        return $query->result_array();
    }

    public function findById($id)
    {
        $query = $this->db->get_where('penilaian', array('id' => $id));
        return $query->row_array();
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO penilaian (nama, keterangan) VALUES (?, ?)";
        $this->db->query($sql, $data);
    }

    public function update($data)
    {
        $sql = "UPDATE penilaian SET nama=?, keterangan=? WHERE id=?";
        $this->db->query($sql, $data);
    }

    public function delete($data)
    {
        $sql = "DELETE FROM penilaian WHERE id=?";
        $this->db->query($sql, $data);
    }
}
